A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/rJXGMM.

 Touch/Drag mouse to make more sPlooshies!

My first play with the wonderful matter.js 2D Physics Engine.



